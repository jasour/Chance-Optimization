function gout = uplus(g)
% +	Unary plus
% +G for funs is G.

% Copyright 2002-2008 by The Chebfun Team. See www.comlab.ox.ac.uk/chebfun/

gout = g;