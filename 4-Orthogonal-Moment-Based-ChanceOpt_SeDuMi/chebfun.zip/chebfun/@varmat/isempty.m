function e = isempty(V)

e = isempty(V.defn);