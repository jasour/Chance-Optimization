function dom = domain(A)
% DOMAIN   Domain of function defintion.

% Copyright 2008 by Toby Driscoll.
% See www.comlab.ox.ac.uk/chebfun.

dom = A.fundomain;

end