function F = uplus(F)
% +	  Unary plus.
% +F for a chebfun is F.

% Copyright 2002-2008 by The Chebfun Team. See www.comlab.ox.ac.uk/chebfun.
