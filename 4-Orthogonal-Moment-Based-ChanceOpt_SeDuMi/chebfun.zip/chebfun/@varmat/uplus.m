function A = uplus(A)
% +  Same varmat.

% Copyright 2008 by Toby Driscoll.
% See www.comlab.ox.ac.uk/chebfun.

end