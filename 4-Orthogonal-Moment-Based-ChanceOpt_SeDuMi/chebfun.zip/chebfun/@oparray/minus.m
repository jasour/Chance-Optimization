function C = minus(A,B)
% -   Difference of oparrays.

% Copyright 2008 by Toby Driscoll. See www.comlab.ox.ac.uk/chebfun.

C = plus(A,-B);

end