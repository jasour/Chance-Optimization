function out = subsasgn(varargin)
% Fun SUBSASGN just call the built-in SUBSASGN.

% Copyright 2002-2008 by The Chebfun Team. See www.comlab.ox.ac.uk/chebfun/

out = builtin('subsasgn',varargin{:});
